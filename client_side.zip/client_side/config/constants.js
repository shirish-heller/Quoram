/* eslint-disable no-unused-vars */
const APP_COLORS = {
  BASE_COLOR: '#3E52C3',
  ACCENT: '#F9BB42',
  PRIMARY_COLOR: '#071936',
  BACKGROUND_COLOR: '#6055CD',
  PAGE_BACKGROUND: '#E0DDF5',
  TERTIARY_COLOR: '#132a54',
  ACCENT_COLOR: '#f5af5d',
  WHITE_SMOKE: '#f5f4f9',
};

export default APP_COLORS;
